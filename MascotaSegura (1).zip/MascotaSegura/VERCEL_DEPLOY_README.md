# Despliegue en Vercel - Aplicación de Avisos de Mascotas

Esta guía proporciona instrucciones detalladas para desplegar la aplicación en Vercel y solucionar problemas comunes de despliegue.

## Archivos de Configuración Importantes

Hemos configurado varios archivos clave para facilitar el despliegue:

1. **vercel.json** - Configuración principal para Vercel
2. **vercel-build.js** - Script de construcción personalizado
3. **vercel.output.json** - Configuración de verificación de salida

## Despliegue Paso a Paso

### 1. Preparación del Repositorio

Sube el código a un repositorio Git:

```bash
git init
git add .
git commit -m "Versión inicial"
git remote add origin https://github.com/tu-usuario/nombre-del-repo.git
git push -u origin main
```

### 2. Configuración en Vercel

1. Ve a [Vercel](https://vercel.com) e inicia sesión
2. Haz clic en "New Project"
3. Importa tu repositorio Git
4. La configuración ya está definida en `vercel.json`, no necesitas cambiar nada
5. Haz clic en "Deploy"

### 3. Solución de Problemas Comunes

#### Error 404 (Not Found)

Si recibes un error 404 después del despliegue:

1. Ve a **Project Settings** > **Build & Development Settings**
2. Configura:
   - **Build Command**: `node vercel-build.js`
   - **Output Directory**: `dist`
3. Guarda y haz clic en "Redeploy" en la sección "Deployments"

#### Problemas con las Rutas API

Si el frontend carga pero las API dan error:

1. Ve a **Project Settings** > **Functions**
2. Asegúrate que el directorio de inclusión de API esté configurado como `/api/*`
3. En la sección **Rewrites**, configura:
   - Source: `/api/(.*)`
   - Destination: `/api/$1`
4. Añade otra regla:
   - Source: `/(.*)`
   - Destination: `/index.html`

#### Errores en la Consola del Navegador

Los errores de consola sobre rutas o recursos no encontrados generalmente se deben a problemas de configuración de rutas. Verifica las secciones anteriores.

## Estructura del Proyecto Desplegado

En Vercel, los archivos se organizan de la siguiente manera:

- `/dist` - Contiene los archivos compilados del frontend
- `/api` - Contiene el servidor backend
- Todos los archivos estáticos del frontend estarán en la raíz del despliegue

## Recursos Adicionales

Para más información sobre despliegues en Vercel, consulta:

- [Documentación oficial de Vercel](https://vercel.com/docs)
- [Solución de problemas en despliegues](https://vercel.com/guides/debugging-deployment-issues)
- [Configuración de dominios personalizados](https://vercel.com/docs/concepts/projects/domains)

## Contacto y Soporte

Si encuentras problemas con el despliegue, puedes:

1. Consultar los logs de despliegue en la sección "Deployments" de tu proyecto
2. Verificar la configuración de rutas en "Settings" > "Rewrites"
3. Consultar las instrucciones detalladas en el archivo `vercel_deployment/INSTRUCCIONES_ACTUALIZADAS.txt`

## Solución a Problemas de Rutas y 404 (Actualización)

Hemos realizado varias mejoras para solucionar los problemas de rutas y errores 404 en Vercel:

1. Creado un archivo `index.html` en la raíz que:
   - Proporciona una página de carga visualmente atractiva
   - Intenta detectar automáticamente la ruta correcta a la aplicación
   - Redirecciona a la aplicación principal (`/client/dist/index.html`)

2. Mejorado el script `vercel-build.js` para:
   - Copiar el archivo `index.html` de la raíz al directorio `dist` 
   - Crear uno básico si no existe
   - Generar los archivos de configuración necesarios

3. Actualizado los metadatos y etiquetas SEO en `client/index.html` con:
   - Títulos y descripciones en español
   - Metadatos para compartir en redes sociales
   - Script para garantizar la carga correcta en Vercel

4. Confirmado que `vercel.json` tiene las configuraciones correctas:
   - Reglas de reescritura para manejar rutas API y frontend
   - Directorio de salida configurado como `dist`
   - Encabezados de caché apropiados

Estas mejoras deberían resolver los problemas de despliegue y garantizar una navegación fluida en la aplicación desplegada en Vercel.

### Flujo de navegación esperado

1. El usuario visita la URL de Vercel (ej: `https://tu-proyecto.vercel.app/`)
2. Se muestra la página de carga desde el `index.html` raíz
3. Se redirige automáticamente a la aplicación principal
4. El sistema de rutas de la aplicación maneja la navegación interna

Si sigues teniendo problemas después de implementar estos cambios, verifica las instrucciones detalladas en `vercel_deployment/INSTRUCCIONES_ACTUALIZADAS.txt`.
