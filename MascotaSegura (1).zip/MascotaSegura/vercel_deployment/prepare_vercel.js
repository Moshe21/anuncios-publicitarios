/**
 * Script para preparar el despliegue en Vercel
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Contenido de las instrucciones en formato text
const instructionsText = `
==============================================================
INSTRUCCIONES PARA DESPLEGAR EN VERCEL
==============================================================

Esta guía te ayudará a desplegar la aplicación de concientización sobre mascotas en apartamentos en la plataforma Vercel.

PRERREQUISITOS
-------------
1. Una cuenta en Vercel (https://vercel.com)
2. Git instalado en tu computadora
3. Node.js (versión 18 o superior)

PASOS PARA EL DESPLIEGUE
----------------------
1. PREPARA TU REPOSITORIO GIT
   - Inicializa Git en la carpeta de tu proyecto: git init
   - Añade todos los archivos: git add .
   - Crea un commit inicial: git commit -m "Versión inicial"
   - Conecta con tu repositorio remoto: git remote add origin https://github.com/tu-usuario/nombre-del-repo.git
   - Envía el código: git push -u origin main

2. CONFIGURACIÓN DE VERCEL
   - El archivo vercel.json ya está incluido en el proyecto y contiene la configuración necesaria

3. DESPLIEGA EN VERCEL
   - Accede a tu cuenta de Vercel: https://vercel.com
   - Haz clic en "New Project"
   - Importa tu repositorio Git
   - Configura el proyecto:
     * Framework Preset: Other
     * Build Command: npm run build
     * Output Directory: dist
     * Install Command: npm install
   - Haz clic en "Deploy"

4. VERIFICA EL DESPLIEGUE
   - Una vez completado, Vercel te proporcionará una URL para acceder a tu aplicación

PROBLEMAS COMUNES Y SOLUCIONES
----------------------------
- Error de CORS: Instala el paquete cors y añádelo a tu servidor en server/index.ts
- Error de Dependencias: Verifica que todas estén en la sección dependencies

PERSONALIZACIÓN ADICIONAL
-----------------------
1. Configura un dominio personalizado desde el panel de Vercel
2. Añade variables de entorno adicionales si tu aplicación las necesita
3. Configura ramas de previsualización para pruebas

NOTA: Cada vez que realices cambios en tu repositorio y los envíes a la rama principal,
Vercel automáticamente realizará un nuevo despliegue con los cambios.
`;

// Guarda las instrucciones como archivo de texto
try {
  fs.writeFileSync(
    path.join(__dirname, 'instrucciones.txt'),
    instructionsText,
    'utf8'
  );
  console.log('✓ Archivo de instrucciones creado correctamente');
} catch (error) {
  console.error('Error al crear el archivo de instrucciones:', error);
}

// Imprime un mensaje para el usuario
console.log('\n=== Preparación para Vercel ===');
console.log('Este script ha creado instrucciones para desplegar en Vercel.');
console.log('Para ver las instrucciones completas, abre el archivo:');
console.log('vercel_deployment/instrucciones.txt');
console.log('\nEl archivo vercel.json ya está configurado en la raíz del proyecto.');
console.log('Sigue las instrucciones del archivo para completar el despliegue.');