# Guía para Desplegar la Aplicación en Vercel

Esta guía te ayudará a desplegar la aplicación de avisos para mascotas en la plataforma Vercel.

## Prerrequisitos

1. Una cuenta en [Vercel](https://vercel.com)
2. Git instalado en tu computadora
3. Node.js (versión 18 o superior)

## Pasos para el Despliegue

### 1. Prepara tu Repositorio Git

Primero, necesitas tener tu proyecto en un repositorio Git (GitHub, GitLab o Bitbucket):

```bash
# Inicializa Git en la carpeta de tu proyecto
git init

# Añade todos los archivos
git add .

# Crea un commit inicial
git commit -m "Versión inicial"

# Crea un repositorio en GitHub/GitLab/Bitbucket y conecta tu repositorio local
git remote add origin https://github.com/tu-usuario/nombre-del-repo.git
git push -u origin main
```

### 2. Crea el archivo de configuración de Vercel

Crea un archivo llamado `vercel.json` en la raíz de tu proyecto con el siguiente contenido:

```json
{
  "version": 2,
  "builds": [
    {
      "src": "server/index.ts",
      "use": "@vercel/node"
    },
    {
      "src": "package.json",
      "use": "@vercel/static-build",
      "config": {
        "distDir": "dist"
      }
    }
  ],
  "routes": [
    {
      "src": "/api/(.*)",
      "dest": "server/index.ts"
    },
    {
      "src": "/(.*)",
      "dest": "dist/$1"
    }
  ]
}
```

### 3. Modifica server/vite.ts

Para asegurarte de que el servidor funcione correctamente en Vercel, modifica la función `setupVite` en `server/vite.ts` para que sea compatible con el entorno de producción:

```typescript
export async function setupVite(app: Express, server: Server) {
  if (process.env.NODE_ENV === 'production') {
    // En producción, servimos los archivos estáticos
    serveStatic(app);
    return;
  }
  
  // El resto del código para desarrollo...
}
```

### 4. Despliega en Vercel

1. Accede a tu cuenta de Vercel: https://vercel.com
2. Haz clic en "New Project"
3. Importa tu repositorio Git
4. Configura el proyecto:
   - Framework Preset: Other
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm install`
5. En la sección de Variables de Entorno, añade:
   - `NODE_ENV` = `production`
6. Haz clic en "Deploy"

### 5. Verifica el Despliegue

Una vez completado el despliegue, Vercel te proporcionará una URL para acceder a tu aplicación (por ejemplo, `https://tu-proyecto.vercel.app`).

## Problemas Comunes y Soluciones

### Error de CORS

Si enfrentas problemas de CORS, añade el siguiente middleware en `server/index.ts`:

```typescript
// Añade esto al inicio del archivo
import cors from 'cors';

// Y en la configuración del servidor Express
app.use(cors());
```

### Error de Dependencias

Si Vercel no instala correctamente las dependencias, verifica que todas las dependencias necesarias estén en la sección `dependencies` (no en `devDependencies`) de tu archivo `package.json`.

### Error de Rutas

Si las rutas no funcionan correctamente, verifica la configuración de `vercel.json` y asegúrate de que las rutas en tu aplicación sean relativas.

## Mantenimiento del Despliegue

Cada vez que hagas un push a tu repositorio Git principal, Vercel automáticamente realizará un nuevo despliegue con los cambios.

Para configurar dominios personalizados, monitoreo, o configuraciones avanzadas, utiliza el panel de control de Vercel.