
==============================================================
APLICACIÓN DE AVISOS MASCOTAS PARA COMUNIDADES DE APARTAMENTOS
==============================================================

Esta es una aplicación web diseñada para crear y personalizar publicaciones en redes sociales sobre tenencia responsable de mascotas en comunidades de apartamentos.

CARACTERÍSTICAS PRINCIPALES
--------------------------
- Creación de publicaciones personalizadas con mensajes de concientización
- Opciones para personalizar imágenes, títulos y descripciones
- Funcionalidad para compartir en diferentes plataformas (Facebook, Twitter, WhatsApp, LinkedIn)
- Interfaz intuitiva y atractiva
- Diseño responsivo para móviles y escritorio

INSTALACIÓN LOCAL
----------------
1. Asegúrate de tener Node.js (v18+) instalado
2. Descomprime el archivo aplicacion_avisos_mascotas.zip
3. Navega a la carpeta del proyecto
4. Instala las dependencias con: npm install
5. Inicia la aplicación con: npm run dev
6. Abre tu navegador en http://localhost:3000

ESTRUCTURA DEL PROYECTO
----------------------
- /client - Código del frontend (React)
- /server - API y lógica del backend (Express)
- /shared - Tipos y esquemas compartidos

REQUISITOS DEL SISTEMA
--------------------
- Node.js v18 o superior
- Navegador web moderno (Chrome, Firefox, Safari, Edge)
- Conexión a Internet para compartir en redes sociales

SOLUCIÓN DE PROBLEMAS
-------------------
Si encuentras algún problema:
1. Asegúrate de tener la versión correcta de Node.js
2. Verifica que todas las dependencias estén instaladas correctamente
3. Limpia la caché del navegador si experimentas problemas con la interfaz
4. Reinicia la aplicación si hay problemas de conexión con la API

EXTENSIONES FUTURAS
-----------------
- Opciones de plantillas para diferentes plataformas
- Publicación programada de contenido
- Seguimiento de análisis de participación
- Soporte para múltiples idiomas
