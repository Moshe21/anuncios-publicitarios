/**
 * Script para crear un archivo ZIP de la aplicación
 * 
 * Este script copia los archivos de instrucciones al directorio raíz
 * y luego imprime los comandos para crear el archivo ZIP.
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.join(__dirname, '..');

// Archivos a copiar del directorio vercel_deployment al directorio raíz
const filesToCopy = [
  { source: 'README_LOCAL.txt', destination: 'README.txt' },
  { source: 'INSTRUCCIONES_ESPAÑOL.txt', destination: 'INSTRUCCIONES.txt' },
];

// Copia los archivos
console.log('Copiando archivos de instrucciones al directorio raíz...');
filesToCopy.forEach(file => {
  try {
    const sourceContent = fs.readFileSync(path.join(__dirname, file.source), 'utf8');
    fs.writeFileSync(path.join(rootDir, file.destination), sourceContent, 'utf8');
    console.log(`✓ ${file.source} -> ${file.destination}`);
  } catch (error) {
    console.error(`Error al copiar ${file.source}: ${error.message}`);
  }
});

// Imprime instrucciones para crear el ZIP
console.log('\n=== Creación del Archivo ZIP ===');
console.log('Para crear el archivo ZIP, ejecuta el siguiente comando en el directorio raíz:');
console.log('\nzip -r aplicacion_avisos_mascotas.zip . -x "node_modules/*" ".git/*" ".replit/*" "vercel_deployment/*"\n');
console.log('O si prefieres usar una herramienta gráfica:');
console.log('1. Selecciona todos los archivos excepto las carpetas node_modules, .git, .replit y vercel_deployment');
console.log('2. Comprime los archivos seleccionados en un archivo ZIP llamado aplicacion_avisos_mascotas.zip');
console.log('\nRecuerda incluir los archivos README.txt e INSTRUCCIONES.txt en el archivo ZIP.');

// Imprime instrucciones adicionales
console.log('\n=== Después de Crear el ZIP ===');
console.log('Este archivo ZIP está listo para distribuir a usuarios que deseen instalar la aplicación localmente.');
console.log('Contiene instrucciones en español e inglés para la instalación y uso.');
console.log('\nPara preparar la aplicación para despliegue en Vercel, consulta las instrucciones en:');
console.log('vercel_deployment/instrucciones.txt o vercel_deployment/instrucciones.html');