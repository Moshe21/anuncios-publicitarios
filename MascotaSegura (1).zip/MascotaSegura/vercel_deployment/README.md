# Guía para Desplegar la Aplicación en Vercel

Esta guía te ayudará a desplegar la aplicación de concientización sobre mascotas en apartamentos en la plataforma Vercel.

## Prerrequisitos

1. Una cuenta en [Vercel](https://vercel.com)
2. Git instalado en tu computadora
3. Node.js (versión 18 o superior)

## Pasos para el Despliegue

### 1. Prepara tu Repositorio Git

Primero, necesitas tener tu proyecto en un repositorio Git (GitHub, GitLab o Bitbucket):

```bash
# Inicializa Git en la carpeta de tu proyecto
git init

# Añade todos los archivos
git add .

# Crea un commit inicial
git commit -m "Versión inicial"

# Crea un repositorio en GitHub/GitLab/Bitbucket y conecta tu repositorio local
git remote add origin https://github.com/tu-usuario/nombre-del-repo.git
git push -u origin main
```

### 2. Configuración de Vercel

El archivo `vercel.json` ya está incluido en el proyecto y contiene la configuración necesaria para el despliegue.

### 3. Despliega en Vercel

1. Accede a tu cuenta de Vercel: https://vercel.com
2. Haz clic en "New Project"
3. Importa tu repositorio Git
4. Configura el proyecto:
   - Framework Preset: Other
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm install`
5. Haz clic en "Deploy"

### 4. Verifica el Despliegue

Una vez completado el despliegue, Vercel te proporcionará una URL para acceder a tu aplicación (por ejemplo, `https://tu-proyecto.vercel.app`).

## Problemas Comunes y Soluciones

### Error de CORS

Si enfrentas problemas de CORS, puedes instalar el paquete cors y añadirlo a tu servidor:

```typescript
// En server/index.ts
import cors from 'cors';
app.use(cors());
```

### Error de Dependencias

Si Vercel no instala correctamente las dependencias, verifica que todas las dependencias necesarias estén en la sección `dependencies` (no en `devDependencies`) de tu archivo `package.json`.

## Personalización Adicional

Una vez desplegada la aplicación, puedes:

1. Configurar un dominio personalizado desde el panel de Vercel
2. Añadir variables de entorno adicionales si tu aplicación las necesita
3. Configurar ramas de previsualización para pruebas antes de desplegar a producción

## Actualizaciones

Cada vez que realices cambios en tu repositorio y los envíes a la rama principal, Vercel automáticamente realizará un nuevo despliegue con los cambios.