/**
 * Script para preparar el paquete de distribución local
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Contenido del README para la distribución local
const readmeContent = `
==============================================================
APLICACIÓN DE AVISOS MASCOTAS PARA COMUNIDADES DE APARTAMENTOS
==============================================================

Esta es una aplicación web diseñada para crear y personalizar publicaciones en redes sociales sobre tenencia responsable de mascotas en comunidades de apartamentos.

CARACTERÍSTICAS PRINCIPALES
--------------------------
- Creación de publicaciones personalizadas con mensajes de concientización
- Opciones para personalizar imágenes, títulos y descripciones
- Funcionalidad para compartir en diferentes plataformas (Facebook, Twitter, WhatsApp, LinkedIn)
- Interfaz intuitiva y atractiva
- Diseño responsivo para móviles y escritorio

INSTALACIÓN LOCAL
----------------
1. Asegúrate de tener Node.js (v18+) instalado
2. Descomprime el archivo aplicacion_avisos_mascotas.zip
3. Navega a la carpeta del proyecto
4. Instala las dependencias con: npm install
5. Inicia la aplicación con: npm run dev
6. Abre tu navegador en http://localhost:3000

ESTRUCTURA DEL PROYECTO
----------------------
- /client - Código del frontend (React)
- /server - API y lógica del backend (Express)
- /shared - Tipos y esquemas compartidos

REQUISITOS DEL SISTEMA
--------------------
- Node.js v18 o superior
- Navegador web moderno (Chrome, Firefox, Safari, Edge)
- Conexión a Internet para compartir en redes sociales

SOLUCIÓN DE PROBLEMAS
-------------------
Si encuentras algún problema:
1. Asegúrate de tener la versión correcta de Node.js
2. Verifica que todas las dependencias estén instaladas correctamente
3. Limpia la caché del navegador si experimentas problemas con la interfaz
4. Reinicia la aplicación si hay problemas de conexión con la API

EXTENSIONES FUTURAS
-----------------
- Opciones de plantillas para diferentes plataformas
- Publicación programada de contenido
- Seguimiento de análisis de participación
- Soporte para múltiples idiomas
`;

// Instrucciones en español para instalación local
const spanishInstructions = `
INSTRUCCIONES DE INSTALACIÓN
===========================

Para instalar y ejecutar esta aplicación localmente, sigue estos pasos:

1. REQUISITOS PREVIOS
   - Asegúrate de tener Node.js instalado (versión 18 o superior)
   - Puedes descargar Node.js desde: https://nodejs.org/

2. INSTALACIÓN
   - Descomprime el archivo aplicacion_avisos_mascotas.zip en una carpeta
   - Abre una terminal o línea de comandos
   - Navega hasta la carpeta donde descomprimiste los archivos
   - Ejecuta el comando: npm install
   - Espera a que se instalen todas las dependencias

3. EJECUCIÓN
   - Una vez completada la instalación, ejecuta: npm run dev
   - La aplicación comenzará a ejecutarse
   - Abre tu navegador web y visita: http://localhost:3000
   - Ya puedes comenzar a usar la aplicación

4. DETENER LA APLICACIÓN
   - Para detener la aplicación, presiona Ctrl+C en la terminal donde está ejecutándose

En caso de problemas durante la instalación:
- Verifica que Node.js esté correctamente instalado ejecutando: node --version
- Intenta eliminar la carpeta node_modules y el archivo package-lock.json, luego ejecuta npm install nuevamente
- Asegúrate de tener conexión a internet durante la instalación
`;

// Guarda los archivos
try {
  fs.writeFileSync(
    path.join(__dirname, 'README_LOCAL.txt'),
    readmeContent,
    'utf8'
  );
  console.log('✓ Archivo README para distribución local creado correctamente');

  fs.writeFileSync(
    path.join(__dirname, 'INSTRUCCIONES_ESPAÑOL.txt'),
    spanishInstructions,
    'utf8'
  );
  console.log('✓ Instrucciones en español creadas correctamente');
} catch (error) {
  console.error('Error al crear los archivos:', error);
}

// Imprime mensaje para el usuario
console.log('\n=== Preparación del Paquete Local ===');
console.log('Este script ha creado los archivos necesarios para la distribución local.');
console.log('Los siguientes archivos fueron creados:');
console.log('- vercel_deployment/README_LOCAL.txt');
console.log('- vercel_deployment/INSTRUCCIONES_ESPAÑOL.txt');
console.log('\nPara crear el archivo ZIP completo, ejecuta:');
console.log('zip -r aplicacion_avisos_mascotas.zip . -x "node_modules/*" ".git/*" ".replit/*" "vercel_deployment/*"');
console.log('\nIncluye estos archivos de texto en el directorio raíz del ZIP para proporcionar instrucciones completas.');