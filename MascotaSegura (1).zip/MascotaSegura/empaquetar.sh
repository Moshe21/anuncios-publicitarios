#!/bin/bash
# Script para empaquetar la aplicación para distribución local

echo "🚀 Empaquetando aplicación para distribución local..."
node local_deploy/empaquetar.js

echo "💡 Si el proceso fue exitoso, encontrarás el archivo aplicacion_avisos_mascotas_local.zip listo para distribuir"
