#!/usr/bin/env node
// Script para construir el proyecto en Vercel
import { execSync } from 'child_process';
import { writeFileSync, existsSync, mkdirSync } from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

console.log('🔧 Preparando entorno para Vercel...');

// Asegurarse de que estamos usando la versión correcta de Node.js
const nodeVersion = process.version;
console.log(`Usando Node.js ${nodeVersion}`);

// Ejecutar la construcción para el frontend
console.log('🏗️ Construyendo la aplicación frontend...');
try {
  execSync('vite build', { stdio: 'inherit' });
  console.log('✅ Frontend construido correctamente');
} catch (error) {
  console.error('❌ Error construyendo el frontend:', error);
  process.exit(1);
}

// Ejecutar la construcción para el backend
console.log('🏗️ Construyendo el servidor backend...');
try {
  execSync('esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist', { stdio: 'inherit' });
  console.log('✅ Backend construido correctamente');
} catch (error) {
  console.error('❌ Error construyendo el backend:', error);
  process.exit(1);
}

// Crear un archivo _redirects para manejar el enrutamiento del lado del cliente
console.log('📝 Creando archivos de configuración para el enrutamiento...');
const redirects = `
# Enrutar todas las solicitudes de API al servidor backend
/api/*  /api/:splat  200
# Enrutar el resto al index.html para que React Router maneje las rutas del cliente
/*      /index.html  200
`;

// Asegurar que el directorio dist existe
if (!existsSync('dist')) {
  mkdirSync('dist', { recursive: true });
}

try {
  writeFileSync(path.join('dist', '_redirects'), redirects);
  
  // También crear un archivo vercel.json dentro de dist para mayor seguridad
  const vercelConfig = {
    "routes": [
      { "src": "/api/(.*)", "dest": "/api/$1" },
      { "src": "/(.*)", "dest": "/index.html" }
    ]
  };
  
  writeFileSync(
    path.join('dist', 'vercel.json'), 
    JSON.stringify(vercelConfig, null, 2)
  );
  
  // Copiar el index.html personalizado al directorio dist
  console.log('📄 Copiando index.html a dist...');
  if (existsSync('index.html')) {
    try {
      const indexHtml = fs.readFileSync('index.html', 'utf-8');
      writeFileSync(path.join('dist', 'index.html'), indexHtml);
      console.log('✅ index.html copiado correctamente');
    } catch (err) {
      console.error('❌ Error al copiar index.html:', err);
      createBasicHtml();
    }
  } else {
    console.log('⚠️ No se encontró index.html en la raíz, creando uno básico...');
    createBasicHtml();
  }

  function createBasicHtml() {
    // Crear un index.html básico
    const basicHtml = `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Avisos de Mascotas</title>
  <style>
    body { font-family: sans-serif; text-align: center; padding: 50px; }
    h1 { color: #6366f1; }
  </style>
</head>
<body>
  <h1>Avisos de Mascotas</h1>
  <p>Cargando aplicación...</p>
  <script>window.location.href = "/client/dist/index.html";</script>
</body>
</html>`;
    writeFileSync(path.join('dist', 'index.html'), basicHtml);
    console.log('✅ Creado index.html básico alternativo');
  }
  
  console.log('✅ Archivos de configuración creados correctamente');
} catch (error) {
  console.error('❌ Error creando archivos de configuración:', error);
}

console.log('🚀 ¡Construcción completada! El proyecto está listo para ser desplegado en Vercel');