# Instrucciones para Ejecución Local

## Requisitos previos

Para ejecutar esta aplicación localmente, necesitas tener instalado:

- **Node.js** (versión 14 o superior)
- **npm** (generalmente se instala con Node.js)

## Pasos para la instalación

1. **Descomprime el archivo** `aplicacion_avisos_mascotas_local.zip` en la ubicación que prefieras.

2. **Abre una terminal o línea de comandos** en la carpeta donde descomprimiste los archivos.

3. **Instala las dependencias** ejecutando uno de estos comandos:
   
   En sistemas Windows:
   ```
   instalar.bat
   ```
   
   En sistemas Mac/Linux:
   ```
   ./instalar.sh
   ```
   
   Alternativamente, puedes ejecutar directamente:
   ```
   npm install
   ```

4. **Espera** a que se completen las instalaciones. Esto puede tomar unos minutos dependiendo de tu conexión a internet.

## Iniciar la aplicación

Una vez completada la instalación, puedes iniciar la aplicación de dos formas:

### Opción 1: Usando los scripts proporcionados

En sistemas Windows:
```
iniciar.bat
```

En sistemas Mac/Linux:
```
./iniciar.sh
```

### Opción 2: Usando npm

```
npm start
```

## Acceder a la aplicación

Una vez iniciada la aplicación, verás un mensaje confirmando que el servidor está en funcionamiento. Abre tu navegador web y visita:

```
http://localhost:3000
```

La aplicación debería cargarse automáticamente y estarás listo para comenzar a crear avisos de mascotas para tu comunidad de apartamentos.

## Estructura de la aplicación

- `index.html` - Página principal que redirecciona a la aplicación
- `servidor_local.js` - Servidor Express que maneja las peticiones
- `dist/` - Contiene los archivos compilados de la aplicación
- `package.json` - Configuración de dependencias y scripts

## Solución de problemas

Si encuentras algún problema al ejecutar la aplicación, intenta estos pasos:

1. **Asegúrate de que el puerto 3000 no esté siendo utilizado por otra aplicación**. Si está en uso, puedes cambiar el puerto en el archivo `servidor_local.js` modificando la línea `const PORT = process.env.PORT || 3000;`

2. **Verifica que Node.js esté correctamente instalado** ejecutando `node --version` en tu terminal.

3. **Si hay errores durante la instalación**, intenta eliminar la carpeta `node_modules` y el archivo `package-lock.json`, luego ejecuta `npm install` nuevamente.

4. **Si la aplicación no funciona después de iniciarla**, revisa la consola/terminal para ver si hay mensajes de error que puedan indicar el problema.

## Detener la aplicación

Para detener la aplicación, simplemente presiona `Ctrl+C` en la terminal donde está ejecutándose el servidor.

## Contacto y soporte

Si necesitas ayuda adicional con la instalación o uso de la aplicación, no dudes en contactarnos a través de nuestro correo de soporte o canales de comunicación habituales.