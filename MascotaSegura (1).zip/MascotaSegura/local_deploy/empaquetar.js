/**
 * Empaquetar la aplicación para distribución local
 */

import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Obtener __dirname en módulos ES
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

console.log('🚀 Iniciando proceso de empaquetado...');

// 1. Compilar la aplicación cliente y servidor
try {
  console.log('📦 Compilando aplicación cliente...');
  execSync('npm run build', { stdio: 'inherit', encoding: 'utf8' });
  console.log('✅ Compilación completada');
} catch (error) {
  console.error('❌ Error durante la compilación:', error);
  process.exit(1);
}

// 2. Ejecutar script de generación de paquete local
try {
  console.log('📦 Preparando paquete local...');
  execSync('node local_deploy/preparar_local.js', { stdio: 'inherit', encoding: 'utf8' });
  console.log('✅ Paquete local preparado');
} catch (error) {
  console.error('❌ Error al preparar paquete local:', error);
  process.exit(1);
}

console.log('🎉 ¡Empaquetado completado con éxito!');
console.log('📦 El archivo aplicacion_avisos_mascotas_local.zip contiene la aplicación lista para distribución');