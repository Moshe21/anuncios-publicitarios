/**
 * Script para preparar una carpeta con todo lo necesario para ejecutar la aplicación localmente
 * Incluye un index.html en la raíz para facilitar la ejecución
 */

import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';

// Obtener __dirname en módulos ES
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Directorio de salida para la versión local
const LOCAL_DIR = 'aplicacion_avisos_mascotas_local';

// Crear el directorio de salida si no existe
if (!fs.existsSync(LOCAL_DIR)) {
  fs.mkdirSync(LOCAL_DIR, { recursive: true });
  console.log(`✅ Carpeta ${LOCAL_DIR} creada`);
} else {
  console.log(`ℹ️ Carpeta ${LOCAL_DIR} ya existe, continuando...`);
}

// Copiar package.json y modificarlo para la versión local
try {
  const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf-8'));
  
  // Modificar scripts para versión local
  packageJson.scripts = {
    "start": "node servidor_local.js",
    "dev": "tsx servidor_local.js"
  };
  
  // Mantener solo las dependencias necesarias
  const necessaryDeps = [
    "express", 
    "tsx", 
    "typescript",
    "react", 
    "react-dom", 
    "wouter"
  ];
  
  const filteredDeps = {};
  for (const dep of necessaryDeps) {
    if (packageJson.dependencies[dep]) {
      filteredDeps[dep] = packageJson.dependencies[dep];
    }
  }
  packageJson.dependencies = filteredDeps;
  
  // Guardar el package.json modificado
  fs.writeFileSync(
    path.join(LOCAL_DIR, 'package.json'),
    JSON.stringify(packageJson, null, 2)
  );
  console.log('✅ package.json creado');
} catch (error) {
  console.error('❌ Error al crear package.json:', error);
}

// Copiar el index.html raíz
try {
  fs.copyFileSync('index.html', path.join(LOCAL_DIR, 'index.html'));
  console.log('✅ index.html copiado');
} catch (error) {
  console.error('❌ Error al copiar index.html:', error);
}

// Crear un servidor Express básico para la versión local
const serverScript = `/**
 * Servidor local para la aplicación de Avisos de Mascotas
 * Este servidor sirve los archivos estáticos y maneja las redirecciones
 */

const express = require('express');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// Servir archivos estáticos desde la carpeta dist
app.use(express.static('dist'));

// Middleware para procesar JSON
app.use(express.json());

// Simulación básica de almacenamiento en memoria
const posts = [];
let postId = 1;

// Ruta API para obtener posts
app.get('/api/posts', (req, res) => {
  res.json(posts);
});

// Ruta API para crear un nuevo post
app.post('/api/posts', (req, res) => {
  const newPost = {
    id: postId++,
    ...req.body,
    createdAt: new Date().toISOString()
  };
  posts.push(newPost);
  res.status(201).json(newPost);
});

// Ruta API para obtener un post específico
app.get('/api/posts/:id', (req, res) => {
  const post = posts.find(p => p.id === parseInt(req.params.id));
  if (!post) {
    return res.status(404).json({ error: 'Post no encontrado' });
  }
  res.json(post);
});

// Para cualquier otra ruta, servir index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Iniciar el servidor
app.listen(PORT, () => {
  console.log(\`✨ Aplicación de Avisos de Mascotas ejecutándose en http://localhost:\${PORT}\`);
  console.log(\`💡 Usa Ctrl+C para detener el servidor\`);
});
`;

fs.writeFileSync(path.join(LOCAL_DIR, 'servidor_local.js'), serverScript);
console.log('✅ servidor_local.js creado');

// Crear un script para instalar y ejecutar la aplicación
const readmeContent = `# Aplicación de Avisos de Mascotas - Versión Local

Esta carpeta contiene una versión simplificada de la aplicación que puede ejecutarse localmente.

## Instrucciones de instalación

1. Asegúrate de tener Node.js instalado (versión 14 o superior)
2. Abre una terminal en esta carpeta
3. Ejecuta el siguiente comando para instalar las dependencias:

\`\`\`
npm install
\`\`\`

## Instrucciones para ejecutar

1. Una vez instaladas las dependencias, ejecuta:

\`\`\`
npm start
\`\`\`

2. Abre tu navegador y visita: http://localhost:3000

## Información adicional

- Esta es una versión simplificada para ejecución local
- Los datos se almacenan en memoria (se perderán al reiniciar el servidor)
- Para detener el servidor, presiona Ctrl+C en la terminal

## Estructura de archivos

- \`index.html\`: Página principal de la aplicación
- \`servidor_local.js\`: Servidor Express para ejecutar la aplicación
- \`dist/\`: Carpeta con los archivos compilados de la aplicación
- \`package.json\`: Configuración del proyecto y dependencias

## Problemas conocidos

Si encuentras algún problema al ejecutar la aplicación, prueba estos pasos:

1. Asegúrate de haber ejecutado \`npm install\` correctamente
2. Verifica que el puerto 3000 no esté siendo usado por otra aplicación
3. Si sigues teniendo problemas, intenta eliminar la carpeta \`node_modules\` y vuelve a ejecutar \`npm install\`
`;

fs.writeFileSync(path.join(LOCAL_DIR, 'README.md'), readmeContent);
console.log('✅ README.md creado');

// Crear carpeta dist y agregar archivos necesarios
if (!fs.existsSync(path.join(LOCAL_DIR, 'dist'))) {
  fs.mkdirSync(path.join(LOCAL_DIR, 'dist'), { recursive: true });
}

// Reutilizar el buildCommand para generar los archivos (si están disponibles)
try {
  if (fs.existsSync('dist')) {
    // Copiar archivos de dist a la carpeta local
    const copyFolderRecursive = (source, target) => {
      // Verificar si es un directorio
      if (fs.statSync(source).isDirectory()) {
        // Crear directorio si no existe
        if (!fs.existsSync(target)) {
          fs.mkdirSync(target, { recursive: true });
        }
        
        // Leer contenido del directorio
        const files = fs.readdirSync(source);
        
        // Recursivamente copiar contenido
        files.forEach(file => {
          const curSource = path.join(source, file);
          const curTarget = path.join(target, file);
          if (fs.statSync(curSource).isDirectory()) {
            copyFolderRecursive(curSource, curTarget);
          } else {
            fs.copyFileSync(curSource, curTarget);
          }
        });
      } else {
        fs.copyFileSync(source, target);
      }
    };
    
    copyFolderRecursive('dist', path.join(LOCAL_DIR, 'dist'));
    console.log('✅ Archivos de la carpeta dist copiados');
  } else {
    console.log('⚠️ Carpeta dist no encontrada, no se copiaron archivos compilados');
    
    // Crear un index.html básico en dist
    const basicHtml = `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Avisos de Mascotas</title>
  <style>
    body { font-family: sans-serif; text-align: center; padding: 50px; }
    h1 { color: #6366f1; }
    .container { max-width: 800px; margin: 0 auto; }
    .error { color: #ef4444; margin: 20px 0; padding: 15px; border: 1px solid #fee2e2; background-color: #fef2f2; border-radius: 6px; }
  </style>
</head>
<body>
  <div class="container">
    <h1>Avisos de Mascotas</h1>
    <div class="error">
      <p><strong>¡Error!</strong> Los archivos compilados no fueron encontrados.</p>
      <p>Por favor, ejecuta el siguiente comando para compilar la aplicación:</p>
      <pre>npm run build</pre>
    </div>
    <p>Una vez compilada, reinicia el servidor con: <code>npm start</code></p>
  </div>
</body>
</html>`;
    fs.writeFileSync(path.join(LOCAL_DIR, 'dist', 'index.html'), basicHtml);
    console.log('✅ Creado un archivo index.html básico en dist');
  }
} catch (error) {
  console.error('❌ Error al copiar archivos de dist:', error);
}

// Generar archivo gitignore
fs.writeFileSync(path.join(LOCAL_DIR, '.gitignore'), 'node_modules\n.DS_Store\n');
console.log('✅ .gitignore creado');

// Crear instrucciones para ejecutar la aplicación
const installScript = `#!/bin/bash
# Script para instalar y ejecutar la aplicación localmente

echo "🚀 Instalando dependencias..."
npm install

echo "✨ Instalación completada"
echo "💡 Para iniciar la aplicación, ejecuta: npm start"
`;

fs.writeFileSync(path.join(LOCAL_DIR, 'instalar.sh'), installScript);
if (process.platform !== 'win32') {
  // Hacer el script ejecutable en sistemas Unix/Linux/Mac
  try {
    // En ES Modules, process.platform estaría disponible pero execSync necesita ser invocado correctamente
    execSync(`chmod +x ${path.join(LOCAL_DIR, 'instalar.sh')}`, { encoding: 'utf8' });
  } catch (error) {
    console.error('⚠️ No se pudo hacer ejecutable el script instalar.sh:', error);
  }
}
console.log('✅ instalar.sh creado');

// Versión para Windows (.bat)
const installBatch = `@echo off
echo 🚀 Instalando dependencias...
call npm install

echo ✨ Instalación completada
echo 💡 Para iniciar la aplicación, ejecuta: npm start
pause
`;

fs.writeFileSync(path.join(LOCAL_DIR, 'instalar.bat'), installBatch);
console.log('✅ instalar.bat creado');

// Crear enlaces para facilitar el inicio
const startScript = `#!/bin/bash
# Script para iniciar la aplicación

echo "🚀 Iniciando la aplicación..."
npm start
`;

fs.writeFileSync(path.join(LOCAL_DIR, 'iniciar.sh'), startScript);
if (process.platform !== 'win32') {
  try {
    execSync(`chmod +x ${path.join(LOCAL_DIR, 'iniciar.sh')}`, { encoding: 'utf8' });
  } catch (error) {
    console.error('⚠️ No se pudo hacer ejecutable el script iniciar.sh:', error);
  }
}
console.log('✅ iniciar.sh creado');

// Versión para Windows (.bat)
const startBatch = `@echo off
echo 🚀 Iniciando la aplicación...
npm start
`;

fs.writeFileSync(path.join(LOCAL_DIR, 'iniciar.bat'), startBatch);
console.log('✅ iniciar.bat creado');

// Crear un ZIP con todo
try {
  console.log('📦 Creando archivo ZIP...');
  if (fs.existsSync('aplicacion_avisos_mascotas_local.zip')) {
    fs.unlinkSync('aplicacion_avisos_mascotas_local.zip');
  }
  
  if (process.platform === 'win32') {
    // En Windows, sugerir usar el Explorador para crear el ZIP
    console.log('⚠️ Para Windows: Por favor, comprima manualmente la carpeta para crear el ZIP');
  } else {
    // En sistemas Unix/Linux/Mac, usar el comando zip
    execSync(`zip -r aplicacion_avisos_mascotas_local.zip ${LOCAL_DIR}`, { encoding: 'utf8' });
    console.log('✅ Archivo aplicacion_avisos_mascotas_local.zip creado');
  }
} catch (error) {
  console.error('❌ Error al crear el archivo ZIP:', error);
  console.log('⚠️ Por favor, comprima manualmente la carpeta para crear el ZIP');
}

console.log('\n🎉 ¡Proceso completado! 🎉');
console.log(`📂 Carpeta creada: ${LOCAL_DIR}`);
console.log('📄 Archivo principal: index.html');
console.log('🚀 Para ejecutar la aplicación:');
console.log('   1. Descomprime el archivo aplicacion_avisos_mascotas_local.zip');
console.log('   2. Abre una terminal en la carpeta descomprimida');
console.log('   3. Ejecuta: npm install');
console.log('   4. Inicia la aplicación con: npm start');
console.log('   5. Visita: http://localhost:3000 en tu navegador');