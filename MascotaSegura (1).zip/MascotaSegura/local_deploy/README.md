# Sistema de Empaquetado para Distribución Local

Este directorio contiene scripts que permiten empaquetar la aplicación de Avisos de Mascotas para su distribución y ejecución local. El sistema genera un paquete completo y autónomo que incluye todo lo necesario para ejecutar la aplicación en cualquier computadora con Node.js.

## Cómo Funciona

El sistema de empaquetado:

1. Compila el código fuente de la aplicación
2. Crea una estructura de directorios para distribución local
3. Genera scripts de instalación y ejecución
4. Crea un archivo ZIP listo para distribuir

## Ejecutar el Empaquetado

Para crear el paquete:

### En sistemas Unix/Linux/Mac:

```bash
./empaquetar.sh
```

### En sistemas Windows:

```
empaquetar.bat
```

O ejecutar directamente el script de Node.js:

```
node local_deploy/empaquetar.js
```

## Resultado

Después de ejecutar el script, encontrarás:

- Un directorio `aplicacion_avisos_mascotas_local` con la aplicación empaquetada
- Un archivo ZIP `aplicacion_avisos_mascotas_local.zip` listo para distribuir

## Contenido del Paquete

El paquete incluye:

- `index.html` - Página principal con redirección a la aplicación
- `servidor_local.js` - Servidor Express para ejecutar la aplicación
- `package.json` - Configuración y dependencias
- `dist/` - Archivos compilados de la aplicación
- `instalar.sh` / `instalar.bat` - Scripts para instalar dependencias
- `iniciar.sh` / `iniciar.bat` - Scripts para iniciar la aplicación
- `README.md` - Instrucciones para el usuario final

## Uso por parte del usuario final

El usuario final simplemente necesita:

1. Descomprimir el archivo ZIP
2. Ejecutar el script de instalación (`instalar.sh` o `instalar.bat`)
3. Ejecutar el script de inicio (`iniciar.sh` o `iniciar.bat`)
4. Acceder a la aplicación en http://localhost:3000

## Consideraciones

- El paquete requiere que el usuario tenga Node.js instalado (v14 o superior)
- Todas las dependencias se instalan localmente durante el proceso de instalación
- La aplicación se ejecuta completamente en el entorno local del usuario
- Los datos se almacenan en memoria (se pierden al cerrar la aplicación)