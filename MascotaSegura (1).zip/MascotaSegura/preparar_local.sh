#!/bin/bash
# Script para preparar la versión local de la aplicación

echo "🚀 Preparando versión local de la aplicación..."
node local_deploy/preparar_local.js

echo "💡 Para más información, consulta el archivo README.md dentro de la carpeta aplicacion_avisos_mascotas_local"
